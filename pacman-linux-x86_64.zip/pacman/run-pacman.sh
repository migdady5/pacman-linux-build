#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
exec ./pacman config.json
